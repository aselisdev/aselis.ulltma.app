 $(document).ready(function(){
        $("#logoutmsg").modal('show');
    });