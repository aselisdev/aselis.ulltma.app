 $(document).ready(function(){
      if({{daysleft}} < 20)
        $("#alert").modal('show');
    });